﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace DataAccessLayer
{
    public class Repository <T> : IRepository<T> where T: class
    {
        private   DbContext context;
        protected DbSet<T>  set;

        public Repository(DbContext datacontext) {
            set = datacontext.Set<T>();
        }//end constructor

        public void Insert(T entity) {
            using (context = new SchoolDBEntities())
            {
                context.Entry(entity).State = EntityState.Added;
                context.SaveChanges();
            }            
            Console.WriteLine("Added and saved");
        }// end Insert

        public void Delete(T entity) {
            using (context = new SchoolDBEntities()) {
                context.Entry(entity).State = EntityState.Deleted;
                context.SaveChanges();
                Console.WriteLine("Removed record.");
            }
        }// end Delete

        public void Update(T entity) {
            using (context = new SchoolDBEntities()) {
                context.Entry(entity).State = EntityState.Modified;
                context.SaveChanges();
                Console.WriteLine("Updated.");
            }
        }//end Update

        public IEnumerable<T> GetAll() {
            return set;
        }//end GetAll()

        public T GetById(int id) {
            return set.Find(id);
        }



    }// end class Repository


    public interface IStandardRepository : IRepository<Standard>
    {

    }

    public interface IStudentRepository : IRepository<Student>
    {

    }

    public class StandardRepository : Repository <Standard>, IStandardRepository
    {
        public StandardRepository() : base(new SchoolDBEntities()) 
        {
    
        }
    }//end class StandardRepository

    public class StudentRepository : Repository <Student>,IStudentRepository
    {
        public StudentRepository() : base(new SchoolDBEntities()) {
            
        }
    }//end class StudentRepository



}// end namespace
