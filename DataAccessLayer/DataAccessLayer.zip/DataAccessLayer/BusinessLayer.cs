﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class BusinessLayer : IBusinessLayer
    {

        private readonly IStandardRepository _IStandardRepository;
        private readonly IStudentRepository _IStudentRepository;
        public BusinessLayer() {
            _IStandardRepository = new StandardRepository();
            _IStudentRepository = new StudentRepository();
        }

        public void printOverallMenu() {
            int menu = 0;
            bool loop = true;
            BusinessLayer businessLayer = new BusinessLayer();
            do
            {               
                Console.WriteLine("1. Student Menu" + "\n" + "2. Standard Menu" + "\n" + "3. Quit");
                menu = Int32.Parse(Console.ReadLine());
                switch (menu)
                {
                    case 1:
                        businessLayer.printStudentMenu();
                        break;
                    case 2:
                        businessLayer.printStandardMenu();
                        break;
                    case 3:
                        loop = false;
                        break;

                }//end switch statement            
            } while (loop);

        }//end printOverallMenu

        //Student specific functions
        //Finished: Insert, Delete
        //Need: Update, Search for one, list all
        public void addStudent(Student student) {
            int studentID = 0, standardID = 0;
            string name = null;
            student = new Student();

            Console.WriteLine("Enter the student ID: ");
            studentID = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Enter the name of the student: ");
            name = Console.ReadLine();
            Console.WriteLine("Enter the standard ID: ");
            standardID = Int32.Parse(Console.ReadLine());

            student.StudentID = studentID;
            student.StudentName = name;
            student.StandardId = standardID;
            student.RowVersion = null;
            _IStudentRepository.Insert(student);
        }//end addStudent

        public void deleteStudent(Student student) {            
            string name = null;
            Console.WriteLine("Enter name of student to delete: ");
            name = Console.ReadLine();
            using (var ctx = new SchoolDBEntities()) {
                student = ctx.Students.Where(s => s.StudentName == name).FirstOrDefault<Student>();
            }
            if (student == null) {
                Console.WriteLine("Record doesn't exist.");
            }
            _IStudentRepository.Delete(student);
        }//end deleteStudent

        public void updateStudent(Student student) {
            string name = null;
            Console.WriteLine("Enter the name of the student you want to update: ");
            name = Console.ReadLine();

            //Find the student the user wants to modify by the name
            using (var ctx = new SchoolDBEntities()) {
                student = ctx.Students.Where(s => s.StudentName == name).FirstOrDefault<Student>();
            }
            if (student == null)
            {
                Console.WriteLine("Record doesn't exist. Closing the program...(temp)");
                Environment.Exit(0); //temporarily close the program
            }
            //Confirm that the student wants to update the student
            Console.WriteLine("Student ID: " + student.StudentID + "\n" + "Student Name: " + student.StudentName +
                "\n" + student.StandardId);
          
                Console.WriteLine("Enter new name for student: ");
                string updatedName = Console.ReadLine();
                student.StudentName = updatedName;
                _IStudentRepository.Update(student);
            
            
        }//end updateStudent

        public Student searchStudentByID(int id) {
            return _IStudentRepository.GetById(id);                                                            
        }


        public IEnumerable<Student> getAllStudents()
        {
            return _IStudentRepository.GetAll();            
        }


        public void printStudentMenu() {
            int menu = 0;
            bool loop = true;
            var student = new Student();
            BusinessLayer businessLayer = new BusinessLayer();
            do
            {
                
                Console.WriteLine("1. Insert Student\n2. Delete Student\n3. Update Student name\n4. Display Students\n5. Search for Student by ID"
                    + "\n" + "6. Main Menu");
                menu = Int32.Parse(Console.ReadLine());
                switch (menu)
                {
                    //Insert Student (works)
                    case 1:
                        businessLayer.addStudent(student);
                        break;
                    //Delete Student (works)
                    case 2:
                        businessLayer.deleteStudent(student);
                        break;
                    //Update Student (works)
                    case 3:
                        businessLayer.updateStudent(student);
                        break;
                    //Display all Students (works)
                    case 4:
                        IEnumerable<Student> list = businessLayer.getAllStudents();
                        foreach (Student s in list)
                        {
                            Console.WriteLine("\nStudent name: " + s.StudentName + "\nStudent ID: " + s.StudentID);
                        }
                        break;
                    //
                    case 5:
                        int id = 0;
                        Console.WriteLine("Enter student ID: ");
                        id = Int32.Parse(Console.ReadLine());
                        student = businessLayer.searchStudentByID(id);
                        Console.WriteLine("Student name: " + student.StudentName + "\nStudent ID: " + student.StudentID);
                        break;
                    case 6:
                        loop = false;
                        break;
                }//end switch
            } while (loop);        
        }//end printStudentMenu




        //For Standard objects
        public void printStandardMenu()
        {
            int menu = 0;
            bool loop = true;
            var standard = new Standard();
            BusinessLayer businessLayer = new BusinessLayer();
            do
            {

                Console.WriteLine("1. Insert Standard\n2. Delete Standard\n3. Update Standard name\n4. Display Standards\n5. Search for Standard by ID"
                    + "\n" + "6. Main Menu");
                menu = Int32.Parse(Console.ReadLine());
                switch (menu)
                {
                    //Insert Student (works)
                    case 1:
                        businessLayer.addStandard(standard);
                        break;
                    //Delete Student (works)
                    case 2:
                        businessLayer.removeStandard(standard);
                        break;
                    //Update Student (works)
                    case 3:
                        businessLayer.updateStandard(standard);
                        break;
                    //Display all Students (works)
                    case 4:
                        IEnumerable<Standard> list = businessLayer.getAllStandards();
                        foreach (Standard s in list)
                        {
                            Console.WriteLine("\nStandard name: " + s.StandardName + "\nStandard ID: " + s.StandardId);
                        }
                        break;
                    
                    case 5:
                        int id = 0;
                        Console.WriteLine("Enter standard ID: ");
                        id = Int32.Parse(Console.ReadLine());
                        standard = businessLayer.GetStandardByID(id);
                        Console.WriteLine("Standard name: " + standard.StandardName + "\nStandard ID: " + standard.StandardId);
                        break;
                    case 6:
                        loop = false;
                        break;
                }//end switch
            } while (loop);
        }//end printStudentMenu


        public void addStandard(Standard standard)
        {
            int standardID = 0;
            string standardName = null, description = null;
            standard = new Standard(); 

            Console.WriteLine("Enter the standard ID: ");
            standardID = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Enter the name of the student: ");
            standardName = Console.ReadLine();
            Console.WriteLine("Enter the description: ");
            description = Console.ReadLine();

            standard.StandardId = standardID;
            standard.StandardName = standardName;
            standard.Description = description;          
            _IStandardRepository.Insert(standard);
        }//end addStudent

        public void removeStandard(Standard standard) {
            string name = null;
            standard = new Standard();
            Console.WriteLine("Enter name of standard to delete: ");
            name = Console.ReadLine();
            using (var ctx = new SchoolDBEntities())
            {
                standard = ctx.Standards.Where(s => s.StandardName == name).FirstOrDefault<Standard>();
            }
            while (standard == null)
            {
                Console.WriteLine("Record doesn't exist. Re-enter: ");
                name = Console.ReadLine();
            }
            _IStandardRepository.Delete(standard);
        }//end deleteStandard

        public void updateStandard(Standard standard)
        {
            string name = null;
            Console.WriteLine("Enter the name of the standard you want to update: ");
            name = Console.ReadLine();
            //Find the student the user wants to modify by the name
            using (var ctx = new SchoolDBEntities())
            {
                standard = ctx.Standards.Where(s => s.StandardName == name).FirstOrDefault<Standard>();
            }
            if (standard == null)
            {
                Console.WriteLine("Record doesn't exist. Closing the program...(temp)");
                Environment.Exit(0); //temporarily close the program
            }
            //Display the student wants to update the student
            Console.WriteLine("Student ID: " + standard.StandardId + "\n" + "Standard Name: " + standard.StandardName +
                "\n" + "Description: " + standard.Description);

            Console.WriteLine("Enter new name for standard: ");
            string updatedName = Console.ReadLine();
            standard.StandardName = updatedName;
            _IStandardRepository.Update(standard);
        }//end updateStandard

        public Standard GetStandardByID(int id)
        {
            return _IStandardRepository.GetById(id);
        }

        public IEnumerable<Standard> getAllStandards() {
            return _IStandardRepository.GetAll();
        }//end getAllStandards


    }// end BusinessLayer
}// end namespace
